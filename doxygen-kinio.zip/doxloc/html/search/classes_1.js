var searchData=
[
  ['platnosc_11',['Platnosc',['../class_kino_rejestracja_1_1_platnosc.html',1,'KinoRejestracja']]],
  ['program_12',['Program',['../class_kino_rejestracja_1_1_program.html',1,'KinoRejestracja']]]
];
