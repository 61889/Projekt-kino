var indexSectionsWithContent =
{
  0: "cdfikmp",
  1: "fp",
  2: "k",
  3: "dim",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables"
};

