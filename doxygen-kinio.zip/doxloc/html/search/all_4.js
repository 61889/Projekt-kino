var searchData=
[
  ['kinorejestracja_5',['KinoRejestracja',['../namespace_kino_rejestracja.html',1,'']]]
];
