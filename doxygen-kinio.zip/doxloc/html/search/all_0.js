var searchData=
[
  ['components_0',['components',['../class_kino_rejestracja_1_1_form1.html#a0526d985a4b138c3614196315b21215d',1,'KinoRejestracja.Form1.components()'],['../class_kino_rejestracja_1_1_form2.html#a3b69df80abc7cde1e7691ebb3cd4aa49',1,'KinoRejestracja.Form2.components()'],['../class_kino_rejestracja_1_1_platnosc.html#a983764a534456f17320dc33235a72e33',1,'KinoRejestracja.Platnosc.components()']]]
];
