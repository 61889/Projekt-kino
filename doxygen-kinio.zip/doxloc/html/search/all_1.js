var searchData=
[
  ['dispose_1',['Dispose',['../class_kino_rejestracja_1_1_form1.html#a2d58c964b8cccf18ab54a4d21bc5165a',1,'KinoRejestracja.Form1.Dispose()'],['../class_kino_rejestracja_1_1_form2.html#adfce63da249125e4ad70db8b7ba9620d',1,'KinoRejestracja.Form2.Dispose()'],['../class_kino_rejestracja_1_1_platnosc.html#ac3ca68bfcb63b46f2fc0b7a206a06eb0',1,'KinoRejestracja.Platnosc.Dispose()']]]
];
