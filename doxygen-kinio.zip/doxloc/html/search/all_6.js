var searchData=
[
  ['platnosc_7',['Platnosc',['../class_kino_rejestracja_1_1_platnosc.html',1,'KinoRejestracja']]],
  ['program_8',['Program',['../class_kino_rejestracja_1_1_program.html',1,'KinoRejestracja']]]
];
