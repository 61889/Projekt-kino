var searchData=
[
  ['initializecomponent_15',['InitializeComponent',['../class_kino_rejestracja_1_1_form1.html#ab0cf31168889c032519ef3feb17a51c2',1,'KinoRejestracja.Form1.InitializeComponent()'],['../class_kino_rejestracja_1_1_form2.html#a814bf74b5056194a1e24d8f545bcb822',1,'KinoRejestracja.Form2.InitializeComponent()'],['../class_kino_rejestracja_1_1_platnosc.html#a26c56717224172bf874e7bedabfc6a83',1,'KinoRejestracja.Platnosc.InitializeComponent()']]]
];
