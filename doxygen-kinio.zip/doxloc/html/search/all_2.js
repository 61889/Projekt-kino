var searchData=
[
  ['form1_2',['Form1',['../class_kino_rejestracja_1_1_form1.html',1,'KinoRejestracja']]],
  ['form2_3',['Form2',['../class_kino_rejestracja_1_1_form2.html',1,'KinoRejestracja']]]
];
